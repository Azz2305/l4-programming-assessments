from modules.input_module import get_input
from modules.process_module import add, subtract, multiply, divide
from modules.output_module import print_and_save_result

def main():
    num1, num2 = get_input()

    sum_result = add(num1, num2)
    subtract_result = subtract(num1, num2)
    multiply_result = multiply(num1, num2)
    divide_result = divide(num1, num2)

    print_and_save_result(num1, num2, sum_result, "sum")
    print_and_save_result(num1, num2, subtract_result, "difference")
    print_and_save_result(num1, num2, multiply_result, "product")
    print_and_save_result(num1, num2, divide_result, "quotient")

if __name__ == "__main__":
    main()