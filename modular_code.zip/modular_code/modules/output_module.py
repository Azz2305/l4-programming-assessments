def print_and_save_result(num1, num2, result, operation, file_name="calculations.txt"):
    print(f"The {operation} of {num1} and {num2} is {result}")
    with open(file_name, "a") as file:
        file.write(f"The {operation} of {num1} and {num2} is {result}\n")